export default function mainFunction(){
    return(
        <div></div>
    )
}
export function chnageTheNumber (state = 0, action) {
    switch(action.type){
        case "INCREAMENT" : 
            return state + 1;
        case "DECREAMENT" : 
            return state - 1;
        default : 
            return state;
    }
}
export function liveTyping (state = '', action) {
    switch (action.type) {
        case "LIVETYPINGMETHOD":
            return action.payload
    
        default:
            return state;
    }
}

// export default chnageTheNumber;