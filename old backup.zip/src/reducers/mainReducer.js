import mainFunction, {chnageTheNumber, liveTyping} from "./increamenDecreament";
import { combineReducers } from "redux";

const rootReducer = combineReducers({
    chnageTheNumber,
    liveTyping
})

export default rootReducer;