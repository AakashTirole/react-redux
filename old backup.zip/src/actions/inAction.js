export const incNumber = () =>{
    return{
        type : "INCREAMENT"
    }
}
export const decNumber = () =>{
    return{
        type : "DECREAMENT"
    }
}
export const liveTyping = (e) =>{
    return{
        type : "LIVETYPINGMETHOD",
        // payload : e
    }
}