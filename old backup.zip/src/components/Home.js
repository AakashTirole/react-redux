import {useSelector, useDispatch} from "react-redux";
import {incNumber, decNumber, liveTyping} from "../actions/inAction";

function Home() {
  const [myState, liveTypingState] = useSelector((state) => [state.liveTyping]);
  // const [myState, liveTypingState] = useSelector((state) => [state.chnageTheNumber, state.liveTyping]);
  // const myState2 = useSelector((state) => state.liveTyping);
  const dispatch = useDispatch();

  const handleChange = (e) => {
    dispatch({type: 'LIVETYPINGMETHOD', payload: e.target.value})
  }
  return (
    <div className="App">
      <h2>Increament / Decreament Counter</h2>
      <div>
        <button onClick={()=> dispatch(decNumber())}>-</button>
        <input placeholder='Type' style={{textAlign:'center'}} value = {myState} type="text" />
        <button onClick={()=> dispatch(incNumber())}>+</button>
      </div>
      <h2>{liveTypingState}</h2>
      <div>
        <input onChange={(e)=>handleChange(e)} placeholder='Type' style={{textAlign:'center'}} type="text" />
        {/* <input onChange={(e)=>dispatch(liveTyping(e.target.value))} placeholder='Type' style={{textAlign:'center'}} type="text" /> */}
      </div>
    </div>
  );
}

export default Home;
